const Discord = require("discord.js");

module.exports.run = async (bot,message,args) => {
      let botembed = new Discord.RichEmbed()
      .setDescription("Bot Information")
      .setColor("#15f153")
      .addField("Bot Name", bot.user.username)
      .addField("Bot Owner", "Tee#7615")
      .addField("Date of creation", "30/07/2018")
      return message.channel.send(botembed);
  

}

module.exports.help = {
  name: "botinfo"
}
