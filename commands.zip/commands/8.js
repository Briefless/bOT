const Discord = require('discord.js');

exports.run = async (client, message, args, tools) => {

  let newEmbed = new Discord.RichEmbed()
  .setDescription("__Commands For Aeonian Bot__")
  .setColor("#bc0000")
  .addField("avatar", `avatar @user`)
  .addField("kick", `kick @user`)
  .addField("ban", `ban @user`)
  .addField("prune", `prune (amount)`)
};

exports.help = {
  name: "help"
}
