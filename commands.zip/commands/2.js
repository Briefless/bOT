const Discord = require("discord.js");

module.exports.run = async (bot,message,args) => {
  let bUser = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[0]));
    if(!bUser) return message.channel.send("Can't find user!");
    let bReason = args.join(" ").slice(22);
    if(!message.member.hasPermission("BAN_MEMBERS")) return message.channel.send("Heh, nice try. *laughs*");
    if(bUser.hasPermission("BAN_MEMBERS")) return message.channel.send("This person is a moderator.");

    let banEmbed = new Discord.RichEmbed()
    .setDescription("__Ban__")
    .setColor("#bc0000")
    .addField("Banned User", `${bUser} with ID ${bUser.id}`)
    .addField("Banned By", `<@${message.author.id}> with ID ${message.author.id}`)
    .addField("Banned In", message.channel)
    .addField("Time", message.createdAt)
    .addField("Reason", bReason);

    let incidentchannel = message.guild.channels.find(`name`, "logs");
    if(!incidentchannel) return message.channel.send("Hmm, either you have no channel named logs, or I can't speak in there.");

    message.guild.member(bUser).ban(bReason);
    incidentchannel.send(banEmbed);


}

module.exports.help = {
  name: "ban"
}
